const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const polls = new Map();

app.use(express.static(__dirname));
app.get('/', (_req, res) => res.sendFile(path.join(__dirname, 'crorepati-quiz.html')));

function publicPoll(poll) {
  return {
    room: poll.room,
    question: poll.question,
    options: poll.options,
    counts: poll.counts,
    total: poll.votes.size,
    open: poll.open,
    timeLeft: Math.max(0, Math.ceil((poll.endsAt - Date.now()) / 1000))
  };
}

function broadcast(poll) {
  io.to(poll.room).emit('poll:update', publicPoll(poll));
}

function closePoll(poll) {
  if (!poll || !poll.open) return;
  poll.open = false;
  clearInterval(poll.ticker);
  io.to(poll.room).emit('poll:closed', publicPoll(poll));
  setTimeout(() => polls.delete(poll.room), 10 * 60 * 1000);
}

io.on('connection', (socket) => {
  socket.on('host:start-poll', (data, ack = () => {}) => {
    const room = String(data && data.room || '');
    const options = data && data.options;
    const duration = Number(data && data.duration) || 30;
    if (!/^kbc-[a-z0-9-]{6,40}$/i.test(room) || !Array.isArray(options) || options.length !== 4) {
      return ack({ ok: false });
    }
    const poll = {
      room,
      question: String(data.question || '').slice(0, 300),
      options: options.map((option) => String(option).slice(0, 160)),
      counts: [0, 0, 0, 0], votes: new Map(), open: true,
      endsAt: Date.now() + Math.min(Math.max(duration, 10), 60) * 1000
    };
    polls.set(room, poll);
    socket.join(room);
    poll.ticker = setInterval(() => {
      broadcast(poll);
      if (Date.now() >= poll.endsAt) closePoll(poll);
    }, 1000);
    broadcast(poll);
    ack({ ok: true });
  });

  socket.on('audience:join', (room, ack = () => {}) => {
    const poll = polls.get(String(room || ''));
    if (!poll) return ack({ ok: false, message: 'This poll is unavailable or has expired.' });
    socket.join(poll.room);
    ack({ ok: true, poll: publicPoll(poll) });
  });

  socket.on('audience:vote', (data, ack = () => {}) => {
    const poll = polls.get(String(data && data.room || ''));
    const option = Number(data && data.option);
    if (!poll || !poll.open || !Number.isInteger(option) || option < 0 || option > 3) {
      return ack({ ok: false, message: 'Voting is closed.' });
    }
    const previous = poll.votes.get(socket.id);
    if (previous !== undefined) poll.counts[previous]--;
    poll.votes.set(socket.id, option);
    poll.counts[option]++;
    broadcast(poll);
    ack({ ok: true });
  });
});

const port = process.env.PORT || 3000;
server.listen(port, () => console.log(`KBC live poll running on port ${port}`));
